"""
A port of django-forms-builder for Mezzanine. Allows admin users to create
their own HTML5 forms and export form submissions as CSV.
"""
from __future__ import unicode_literals

from mezzanine import __version__
