"""
Provides abstract models and admin features used throughout the various
Mezzanine apps.
"""
from __future__ import unicode_literals

from mezzanine import __version__
