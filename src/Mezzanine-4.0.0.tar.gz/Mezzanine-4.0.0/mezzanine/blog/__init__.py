"""
Provides a blogging app with posts, keywords, categories and comments.
Posts can be listed by month, keyword, category or author.
"""
from __future__ import unicode_literals

from mezzanine import __version__
