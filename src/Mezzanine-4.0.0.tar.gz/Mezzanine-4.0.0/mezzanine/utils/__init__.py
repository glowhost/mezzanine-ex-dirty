"""
Various utility functions used throughout the different Mezzanine apps.
"""
from __future__ import unicode_literals
