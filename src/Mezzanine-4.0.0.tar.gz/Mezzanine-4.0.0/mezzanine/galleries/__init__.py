"""
Implements a photo gallery content type.
"""
from __future__ import unicode_literals

from mezzanine import __version__
