
# STATIC_URL = "/static/"
# FORMS_USE_HTML5 = True
# APPEND_SLASH = False
# RICHTEXT_FILTERS = ()
# COMMENTS_DISQUS_SHORTNAME = "teststeve"
# COMMENTS_DISQUS_API_PUBLIC_KEY = "ZlX6OaQk41yMroy7oCB0nrW8cQnSkfp4wgCzbJQTNg5UBVVQh5Uj1sP6mUvRsDpB"
# COMMENTS_DISQUS_API_SECRET_KEY = "To2ogLHD0vPQoNf7GUyXZKsNkzPqz2yBqpzc4O6obeihekYGynpdF6q5IYM4gTT3"
# EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
# PAGE_MENU_TEMPLATES_DEFAULT = [1,2,7,5,8,9]


#ADMIN_REMOVAL = ["django.contrib.sites.models.Site"]

SEARCH_MODEL_CHOICES = []
DEBUG = True
SECRET_KEY = NEVERCACHE_KEY = "lol"
BLOG_POST_PER_PAGE = 10

USE_L10N = USE_I18N = True

# USE_MODELTRANSLATION = True
# MODELTRANSLATION_DEFAULT_LANGUAGE = LANGUAGE_CODE = "de"
_ = lambda s: s
LANGUAGES = (
    ('en', _('English')),
    ('de', _('German')),
    ('es', _('Spanish')),
)

TIME_ZONE = "UTC"
ALLOWED_HOSTS = "*"
FILEBROWSER_NORMALIZE_FILENAME = True
BLOG_USE_FEATURED_IMAGE = True

TWITTER_CONSUMER_KEY = "c8bT27co7CVtf6yMUOuGOw"
TWITTER_CONSUMER_SECRET = "VtW9t5VBLYuzXWdI8v7GoMHOZTK2sy99vuyaMqEFzI4"
TWITTER_ACCESS_TOKEN_KEY = "70294554-Gc35NbWbgJizZuLTn0Dpce9EFDYKEGeP3aFTg3cgV"
TWITTER_ACCESS_TOKEN_SECRET = "D2teG87XqKSqrKXfZgJRQXYEJtkzFmQf431e6WlbRRQxU"

xCACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.filebased.FileBasedCache',
        'LOCATION': '/var/tmp/django_cache',
    }
}

# ADMIN_MENU_ORDER = (
#     ("Content", ("pages.Page", "blog.BlogPost", "acctest.CoolProfile",
#        "generic.ThreadedComment", ("Media Library", "fb_browse"),)),
#     ("Site", ("sites.Site", "redirects.Redirect", "conf.Setting")),
#     ("Users", ("auth.User", "auth.Group",)),
# )

DATABASES = {
    "default": {
        # Ends with "postgresql_psycopg2", "mysql", "sqlite3" or "oracle".
        "ENGINE": "django.db.backends.sqlite3",
        # DB name or path to database file if using sqlite3.
        "NAME": "dev.db",
        # Not used with sqlite3.
        "USER": "",
        # Not used with sqlite3.
        "PASSWORD": "",
        # Set to empty string for localhost. Not used with sqlite3.
        "HOST": "",
        # Set to empty string for default. Not used with sqlite3.
        "PORT": "",
    }
}

xDATABASES = {
    "default": {
        # Ends with "postgresql_psycopg2", "mysql", "sqlite3" or "oracle".
        "ENGINE": "django.db.backends.postgresql_psycopg2",
        # DB name or path to database file if using sqlite3.
        "NAME": "mezzanine",
        # Not used with sqlite3.
        "USER": "postgres",
        # Not used with sqlite3.
        "PASSWORD": "svn504",
        # Set to empty string for localhost. Not used with sqlite3.
        "HOST": "127.0.0.1",
        # Set to empty string for default. Not used with sqlite3.
        "PORT": "",
    }
}

xDATABASES = {
    "default": {
        # Ends with "postgresql_psycopg2", "mysql", "sqlite3" or "oracle".
        "ENGINE": "django.db.backends.mysql",
        # DB name or path to database file if using sqlite3.
        "NAME": "mezzanine",
        # Not used with sqlite3.
        "USER": "root",
        # Not used with sqlite3.
        "PASSWORD": "",
        # Set to empty string for localhost. Not used with sqlite3.
        "HOST": "127.0.0.1",
        # Set to empty string for default. Not used with sqlite3.
        "PORT": "",
    }
}

# # EXTRA_MODEL_FIELDS = ((
# #         'mezzanine.blog.models.BlogPost.foo',
# #         'ForeignKey',
# #         ('blog.blogpost',),
# #         {'blank': True, "null": True},
# # ),)

INSTALLED_APPS = (
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.redirects",
    "django.contrib.sessions",
    "django.contrib.sites",
    "django.contrib.sitemaps",
    "django.contrib.staticfiles",
    "mezzanine.boot",
    "mezzanine.conf",
    "mezzanine.core",
    "mezzanine.generic",
    "mezzanine.pages",
    "mezzanine.blog",
    "mezzanine.forms",
    "mezzanine.galleries",
    "mezzanine.twitter",
    "mezzanine.accounts",
    "mezzanine.mobile",
    #"acctest",
    #'template_timings_panel',
)

#RICHTEXT_WIDGET_CLASS = 'tinymezzce4.widgets.TinyMceWidget'
#TINYMCE_SETUP_JS = '/static/tinymezzce4/js/tinymce_setup.js'

# xDEBUG_TOOLBAR_PANELS = [
#     'debug_toolbar.panels.versions.VersionsPanel',
#     'debug_toolbar.panels.timer.TimerPanel',
#     'debug_toolbar.panels.settings.SettingsPanel',
#     'debug_toolbar.panels.headers.HeadersPanel',
#     'debug_toolbar.panels.request.RequestPanel',
#     'debug_toolbar.panels.sql.SQLPanel',
#     'debug_toolbar.panels.staticfiles.StaticFilesPanel',
#     'debug_toolbar.panels.templates.TemplatesPanel',
#     'debug_toolbar.panels.cache.CachePanel',
#     'debug_toolbar.panels.signals.SignalsPanel',
#     'debug_toolbar.panels.logging.LoggingPanel',
#     'debug_toolbar.panels.redirects.RedirectsPanel',
# ]

# DEBUG_TOOLBAR_PANELS += [
#     'template_timings_panel.panels.TemplateTimings.TemplateTimings',
# ]

# Store these package names here as they may change in the future since
# at the moment we are using custom forks of them.
PACKAGE_NAME_FILEBROWSER = "filebrowser_safe"
PACKAGE_NAME_GRAPPELLI = "grappelli_safe"

#########################
# OPTIONAL APPLICATIONS #
#########################

# These will be added to ``INSTALLED_APPS``, only if available.
OPTIONAL_APPS = (
    #"debug_toolbar",
    "django_extensions",
    "compressor",
    PACKAGE_NAME_FILEBROWSER,
    PACKAGE_NAME_GRAPPELLI,
)
USE_SOUTH = True

#AUTH_USER_MODEL = "acctest.CoolUser"
#AUTH_PROFILE_MODULE = "acctest.CoolProfile"
#INSTALLED_APPS = ("acctest",) + INSTALLED_APPS

# FABRIC = {
#     "HOSTS": ["lal"],
#     "SSH_USER": "vagrant",
#     "SSH_PASS": "vagrant",
#     "REPO_URL": "https://bitbucket.org/stephenmcd/mezzproj",
#     "REQUIREMENTS_PATH": "requirements/project.txt",
#     "PROJECT_NAME": "mezz",
#     "DB_PASS": "kouilol",
#     "SECRET_KEY": "asdfasdfasdf",
#     "GUNICORN_PORT": 8001,
# }

FABRIC = {
    "HOSTS": ["10.10.10.10"],
    "SSH_USER": "vagrant",
    "SSH_PASS": "vagrant",
    "REPO_URL": "https://bitbucket.org/stephenmcd/mezzproj",
    "REQUIREMENTS_PATH": "requirements.txt",
    "PROJECT_NAME": "mezzproj",
    "DB_PASS": "pass",
    "SECRET_KEY": "keyf",
    "GUNICORN_PORT": 8000,
}

#TEST_RUNNER = "django.test.simple.DjangoTestSuiteRunner"
