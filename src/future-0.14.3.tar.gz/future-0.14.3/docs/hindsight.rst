In a perfect world, the new metaclass syntax should ideally be available in
Python 2 as a `__future__`` import like ``from __future__ import
new_metaclass_syntax``.

